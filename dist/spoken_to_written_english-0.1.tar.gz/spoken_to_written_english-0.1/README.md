**Spoken to Written English**

Installation:
1. Clone this project repository
```bash
git clone https://github.com/asagar60/spoken_to_written_english
```
2. Install this python package
```bash
pip install dist\spoken_to_written_english-0.1-py3-none-any.whl
```

This repo attempts to convert spoken digits to written ones.

**Usage**
- Clone this repository and import it as package
- Call function convert_spoken_to_english(text), where text is assumed to be a 2 word sentence.

**Results**
- convert_spoken_to_english("Triple A")    -  AAA
- convert_spoken_to_english("two dollars") -  $2
- convert_spoken_to_english("C M")         -  CM
